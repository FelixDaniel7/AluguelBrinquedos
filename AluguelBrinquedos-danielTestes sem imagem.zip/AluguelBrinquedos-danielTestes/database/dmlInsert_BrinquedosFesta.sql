USE BrinquedosFesta;


INSERT INTO  Administrador(Nome,Email,Login,Senha,NivelAcesso)
Values ('blabla', 'daniel@gmail.com','blaba213','123',1);

INSERT INTO  Cliente(Celular)
Values ('1234567897');

select * from cliente;

UPDATE Usuario 
SET Senha = '123'
WHERE Email = 'danielfernandesdk27@gmail.com';

SELECT * FROM Usuario 
WHERE Login = 'Daniel' AND Senha = 'a3dd91d922fcff42f64ac37e9140b02a00e4ce01' AND Tipo = 'Administrador';


INSERT INTO Equipamento (Nome,Descricao,Preco) 
VALUES ('Piscina de Bolinhas','100m X 200m',80.00);
INSERT INTO Equipamento (Nome,Descricao,Preco) 
VALUES ('Cama elástica','165m X 298m Material Super Elastico',120.00);
INSERT INTO Equipamento (Nome,Descricao,Preco) 
VALUES ('Castelo inflável','138m X 120m Anti-furo',150.00);
INSERT INTO Equipamento (Nome,Descricao,Preco) 
VALUES ('Alogão Doce','3 velocidades',100.00);

/*
Nome VARCHAR(20),
    Descricao VARCHAR(100),
    Peso DECIMAL(7,2),/*em KG
    Altura DECIMAL(7,2),/*em Metros
    Comprimento DECIMAL(7,2),/*em Metros
    Largura DECIMAL(7,2),/*em Metros
    Preco DECIMAL(8,2)
    Status ENUM('Alugado','Disponivel')*/


INSERT INTO Datas (DataDisponivel,CodEquipamento)
VALUES ('2019-08-06',4);

select * from Datas;

Select nome from equipamento where nome LIKE '%cama%';

SELECT E.Nome , E.Preco , D.DataDisponivel 
FROM Equipamento AS E INNER JOIN Datas AS D 
ON E.CodEquipamento = D.CodEquipamento; 
SELECT * FROM Cliente WHERE Nome LIKE 'Rodolfo%';

INSERT INTO Supervisao(CodSupervisao,TipoSupervisao,ValorSupervisao)
VALUES(0,0);

select * from Equipamento;

INSERT INTO Aluguel (CodCliente,CodEquipamento,DataAluguel,Data_de_uso,
HorasAlugado,DataMontagem,DataDesmontagem,EnderecoMontagem,
Supervisao,PrecoFinal,FormaPagamento) 
VALUES (1,4,'2019-07-30 02:30:55','2019-08-05',
3.5,'2019-08-05 14:00:00','2019-08-05 17:00:00','Rua das rosas, 485-Jardim Nemus',
0,556.47,'Cartão');
select * from Aluguel;

