<?php 
/*tudo relacionado aos equipamentos
cadastro 
update
delete
*/
include_once('../model/equipamento.php');

$equi = new Equipamento();/*Instancia do objeto da classe para poder usar as funçoes da classe*/

$acao = filter_input(INPUT_POST, 'acao', FILTER_SANITIZE_STRING);


    switch ($acao) {

        case 'form_cadastrar_equi':

            ?>
            
            <form  action="" method="post" class="form" name="form_cad_equipamento" >
                <div class="form-group">
                    <label for="exampleInputEmail1">Nome</label>
                    <input type="text" name="txtnomeEquipamento" class="form-control" aria-describedby="emailHelp" placeholder="Nome Equipamento" required>             
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Descrição</label>
                    <input type="text" name="txtdescricao" class="form-control" placeholder="Descrição" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Peso(KG)</label>
                    <input type="number" step="0.01" name="txtpeso" class="form-control" placeholder="Peso" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Altura(CM)</label>
                    <input type="number" name="txtaltura" class="form-control" placeholder="Altura" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Comprimento(CM)</label>
                    <input type="number" name="txtcomprimento" class="form-control" placeholder="Comprimento" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Largura(CM)</label>
                    <input type="number" name="txtlargura" class="form-control" placeholder="Largura" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Preço</label>
                    <input type="number" step="0.01" name="txtpreco" class="form-control" placeholder="Preço" required>
                </div>
                
                <button type="submit" class="btn btn-dark">Cadastrar Equipamento</button>
                </form>
                
            <?php
            break;
        
        case 'cadastrar_equi':

            //$CodEquipamento = filter_input(INPUT_POST, 'CodEquipamento', FILTER_SANITIZE_NUMBER_INT);
    
            $equi->Nome = filter_input(INPUT_POST, 'txtnomeEquipamento', FILTER_SANITIZE_STRING);
            $equi->Descricao = filter_input(INPUT_POST, 'txtdescricao', FILTER_SANITIZE_STRING); 
            $equi->Preco = filter_input(INPUT_POST, 'txtpreco', FILTER_SANITIZE_STRING);//DOUBLE
            $equi->Peso = filter_input(INPUT_POST, 'txtpeso', FILTER_SANITIZE_STRING);
            $equi->Altura = filter_input(INPUT_POST, 'txtaltura', FILTER_SANITIZE_STRING);
            $equi->Comprimento = filter_input(INPUT_POST, 'txtcomprimento', FILTER_SANITIZE_STRING);
            $equi->Largura = filter_input(INPUT_POST, 'txtlargura', FILTER_SANITIZE_STRING);

            if($equi->CadastrarEquipamento()){
                echo 'cadastrou';
            }
            break;

        case 'form_editar_equi':/*Formulario Preenchido com os dados para EDIÇÂO*/

            $CodEquipamento = filter_input(INPUT_POST, 'CodEquipamento', FILTER_SANITIZE_NUMBER_INT);

            $dados = $equi->RetornarDados($CodEquipamento);//pegando o retorno do metodo e colocando na variavel $equi
            
            /*FORM Q VAI DENTRO DA MODAL*/
            ?>

                            <form method="post" class="form" name="form_editar_equipamento">
                    <input type="hidden" name="CodEquipamento" value="<?php echo $dados->CodEquipamento; ?>">
                    Nome
                    <input type="text" name="txtnomeEquipamento" value="<?php echo $dados->Nome;?>"><br>
                    Descricao
                    <input type="text" name="txtdescricao" value="<?php echo $dados->Descricao;?>"><br>
                    Peso
                    <input type="number" step="0.01" name="txtpeso" value="<?php echo $dados->Peso;?>"><br>
                    Altura
                    <input type="number" name="txtaltura" value="<?php echo $dados->Altura;?>"><br>
                    Comprimento
                    <input type="number" name="txtcomprimento" value="<?php echo $dados->Comprimento;?>"><br>
                    Largura
                    <input type="number" name="txtlargura" value="<?php echo $dados->Largura;?>"><br>
                    Preço
                    <input type="number" step="0.01" name="txtpreco" value="<?php echo $dados->Preco;?>"><br>

                    <button type="submit" id="btn_atualiza" >
                        Atualizar Equipamento 
                    </button>
                </form>

            <?php
            break;

        case 'editar_equi':

            $equi->CodEquipamento = filter_input(INPUT_POST, 'CodEquipamento', FILTER_SANITIZE_NUMBER_INT);
            $equi->Nome = filter_input(INPUT_POST, 'txtnomeEquipamento', FILTER_SANITIZE_STRING);
            $equi->Descricao = filter_input(INPUT_POST, 'txtdescricao', FILTER_SANITIZE_STRING); 
            $equi->Preco = filter_input(INPUT_POST, 'txtpreco', FILTER_SANITIZE_STRING);//DOUBLE
            $equi->Peso = filter_input(INPUT_POST, 'txtpeso', FILTER_SANITIZE_STRING);
            $equi->Altura = filter_input(INPUT_POST, 'txtaltura', FILTER_SANITIZE_STRING);
            $equi->Comprimento = filter_input(INPUT_POST, 'txtcomprimento', FILTER_SANITIZE_STRING);
            $equi->Largura = filter_input(INPUT_POST, 'txtlargura', FILTER_SANITIZE_STRING);

            if ($equi->AtualizarEquipamento()) {
                echo 'atualizou';
            }
            break;

        case 'excluir_equi':
            $equi->CodEquipamento = filter_input(INPUT_POST, 'CodEquipamento', FILTER_SANITIZE_NUMBER_INT);

            if($equi->ExcluirEquipamento()){
                echo 'deletou';
            }
            break;
    }
?>